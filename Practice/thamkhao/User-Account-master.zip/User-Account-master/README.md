# User-Account Dropdown List Items 

User Account Dropdown Menu Using Html CSS & Vanilla Javascript - In this tutorial, you will learn how to create a simple dropdown menu with vanilla Javascript, HTML, and CSS. We'll use just plain JS and CSS, with no frameworks or preprocessor. A Vanilla JavaScript responsive dropdown menu that will be converted into a profile image toggle menu when the screen size is less than a breakpoint you specify in the CSS media queries. Smooth animation is based on CSS3 transforms and transitions.
