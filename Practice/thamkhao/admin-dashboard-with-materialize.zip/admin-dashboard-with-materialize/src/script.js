$('.button-collapse').sideNav();

$('.collapsible').collapsible();

$('select').material_select();