/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates/. Created on : 30-10-2022
 * and open the template in the editor.
 */
package fall22.pe.food;

/**
 *
 * @author hd
 */
public class FoodDAO {

//   your code here
    

  
    
}
